import java.util.ArrayList;

public class GestorTallerBicicletas {
    ArrayList<Bicicleta> bicicletas = new ArrayList<Bicicleta>();


    public void registrarBicicleta(Bicicleta bicicleta) {
        bicicletas.add(bicicleta);
        System.out.println("Bicicleta registrada con éxito");
    }

    public ArrayList<Bicicleta> buscarPorCodigo(String codigo) {
        ArrayList<Bicicleta> resultado = new ArrayList<Bicicleta>();
        for (Bicicleta bicicleta : bicicletas) {
            if (bicicleta.getCodigo().equals(codigo)){
                resultado.add(bicicleta);
            }
        }
        return resultado;

    }
}

